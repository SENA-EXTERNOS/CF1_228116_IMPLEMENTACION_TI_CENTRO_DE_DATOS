function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5fHoY6SI6Cq":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

